<?php


namespace Joomla\Component\Timona\Site\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Application\CmsApplication;

use Joomla\CMS\Language\Text;

use Joomla\CMS\MVC\Controller\AdminController;

use Joomla\CMS\MVC\Factory\MVCFactoryInterface;

use Joomla\Utilities\ArrayHelper;


class TimonaController extends BaseController

{


}

