<?php

namespace Joomla\Component\Timona\Site\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;

use Joomla\CMS\MVC\Model\ListModel;

use Joomla\CMS\Table\Table;

use Joomla\Database\ParameterType;
class UserModel extends ListModel

{

	
}

