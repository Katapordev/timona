  var firebaseConfig = {
    apiKey: "AIzaSyDV92ORzEidu1qehlQyXcWxzWeeEyB0LaE",
    authDomain: "timona-academy.firebaseapp.com",
    databaseURL: "https://timona-academy.firebaseio.com",
    projectId: "timona-academy",
    storageBucket: "timona-academy.appspot.com",
    messagingSenderId: "808457487068",
    appId: "1:808457487068:web:4cd9d72c51b1c53efdea19",
    measurementId: "G-H4MNLTF6HJ"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);